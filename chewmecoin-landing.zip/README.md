# ChewMeCoin Landing Page

Dies ist die offizielle Meme-Coin-Landingpage für **ChewMeCoin ($CHEW)**.

## Features

- Retro-Design im Meme-Stil
- Logo-Integration über IPFS
- Button: $CHEW zu MetaMask hinzufügen

## Deployment

1. Ersetze in `index.html` die Contract-Adresse:
   ```js
   address: 'DEINE_CONTRACT_ADRESSE_HIER'
   ```
2. Lade das Projekt auf GitHub hoch
3. Aktiviere GitHub Pages über Settings → Pages → Source: `main`, Ordner: `/ (root)`

## Lizenz

MIT License
